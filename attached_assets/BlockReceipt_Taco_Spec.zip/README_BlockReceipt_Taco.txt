
# BlockReceipt.ai – Replit Build Spec with Threshold Proxy Re-Encryption (TACo)

## Project Overview
BlockReceipt.ai mints NFT receipts when users make verified purchases. These NFTs are collectible, artistic, and verifiable, stored in a wallet-connected visual album UI. The app uses Threshold Network’s proxy re-encryption (TACo) to protect private receipt data and enable dynamic third-party access.

## Core Tech Stack
- React + Tailwind + shadcn/ui (Frontend)
- Express.js (Backend)
- ERC-1155 Receipt Smart Contract
- NFT.Storage / IPFS (Metadata/Image)
- RainbowKit + Wagmi (Wallet login)
- Threshold TACo (Encryption & Access Control)

## Unique Selling Point
We integrate **Threshold TACo** to:
- Encrypt sensitive data (e.g., warranty ID, serial number)
- Enable **user-controlled access** to Amazon, support teams, etc.
- Highlight user privacy and decentralized control

## TACo Integration
Endpoints:
- POST `/grant-access`
- POST `/revoke-access`
- GET `/metadata/:tokenId` (protected by proxy decryption)

Frontend:
- Show access control UI (grant/revoke)
- Highlight TACo privacy in messaging

## Album UI
Users view NFTs in a “collection binder” organized by category (e.g., Electronics, Fashion). Receipts show metadata, missing categories, and allow for encrypted proof-of-purchase access if desired.

## Notes
- Gas is covered for the user (meta-transactions or backend-funded)
- Initial purchase flow can be simulated with mock endpoints
- Encrypted metadata stored off-chain, public parts on IPFS

## Public Messaging
> “Your receipts. Your wallet. Your rules. Protected by Threshold TACo.”

---

To implement this, all Replit AI agent work must highlight TACo and follow the encrypted metadata flow.
